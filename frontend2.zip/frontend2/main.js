const url = 'http://localhost:3000/api/productos';
const lista = document.getElementById('lista');

// Cache de categorías
let categorias = [];

// Cargar categorías al inicio
async function cargarCategorias() {
  try {
    const response = await fetch('http://localhost:3000/api/categorias');
    if (!response.ok) {
      throw new Error('Error al cargar categorías');
    }
    categorias = await response.json();
  } catch (error) {
    console.error('Error cargando categorías:', error);
  }
}

// Función que devuelve el nombre de la categoría a partir del categoria_id
function getNombreCategoria(categoria_id) {
  const categoria = categorias.find(cat => cat.id === categoria_id);
  return categoria ? categoria.nombre : 'Sin categoría';
}

async function cargarProductos() {
  try {
    const response = await fetch(url);

    if (!response.ok) {
      throw new Error('Error al cargar los datos');
    }

    const productos = await response.json();

    lista.innerHTML = '';

    productos.forEach(producto => {
      const li = document.createElement('li');
      li.innerHTML = `
        <strong>${producto.nombre}</strong><br>
        ${producto.precio}€<br>
        ${getNombreCategoria(producto.categoria_id)}
      `;
      lista.appendChild(li);
    });

  } catch (error) {
    lista.innerHTML = '<li>Error al cargar usuarios</li>';
    console.error(error);
  }
}

// Inicializar: primero cargar categorías, luego productos
(async () => {
  await cargarCategorias();
  await cargarProductos();
})();
